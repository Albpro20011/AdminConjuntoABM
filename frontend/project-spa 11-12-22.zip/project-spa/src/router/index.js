import { createRouter, createWebHashHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  },
  {
    path: '/security/personas',
    name: 'personas',   
    component: () => import('../views/security/PersonView.vue')
  },
  {
    path: '/security/usuarios',
    name: 'usuarios',   
    component: () => import('../views/security/UserView.vue')
  },
  {
    path: '/security/permisos',
    name: 'permisos',   
    component: () => import('../views/security/PermissionView.vue')
  },
  {
    path: '/security/roles',
    name: 'roles',   
    component: () => import('../views/security/RoleView.vue')
  },
  {
    path: '/security/permisos-roles',
    name: 'permisos-roles',   
    component: () => import('../views/security/PermissionRoleView.vue')
  },
  {
    path: '/estate/costes-adminsitracion',
    name: 'costes-adminsitracion',   
    component: () => import('../views/estate/CostManagement.vue')
  },
  {
    path: '/estate/tipos-inmuebles',
    name: 'tipos-inmuebles',   
    component: () => import('../views/estate/PropertyType.vue')
  },
  {
    path: '/parameter/departamentos',
    name: 'departamentos',   
    component: () => import('../views/parameter/DepartmentView.vue')
  },
  {
    path: '/parameter/ciudades',
    name: 'ciudades',   
    component: () => import('../views/parameter/CityView.vue')
  },
  {
    path: '/estate/inmuebles',
    name: 'inmuebles',   
    component: () => import('../views/estate/PropertyView.vue')
  },
  {
    path: '/estate/bitacoras',
    name: 'bitacoras',   
    component: () => import('../views/estate/BinnacleView.vue')
  },
  {
    path: '/estate/datos-conjuntos',
    name: 'datos-conjuntos',   
    component: () => import('../views/estate/ResidenceDataView.vue')
  }




]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
