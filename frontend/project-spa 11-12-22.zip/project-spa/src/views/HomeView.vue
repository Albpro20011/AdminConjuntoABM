<template>
  <div class="container">
    <br>
    <div class="alert alert-dismissible alert-warning">
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      <h4 class="alert-heading">Bienvenidos, este es el resultado del Teams G-53</h4>
      <p class="mb-0">Sistema de Infomación desarrollador por el teams g53-g4.</p>
      <img src="../assets/conjunto.jpg" alt="">
    </div>
  </div>

</template>
