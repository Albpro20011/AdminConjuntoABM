<template>
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Control de Administración</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01"
          aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarColor01">
          <ul class="navbar-nav me-auto">
            <!-- Módulo de seguridad -->
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                aria-expanded="false">Seguridad</a>
              <div class="dropdown-menu">
                <router-link class="dropdown-item" to="/security/personas">Registro de Personas</router-link>
                <router-link class="dropdown-item" to="/security/usuarios">Registro de Usuarios</router-link>
                <div class="dropdown-divider"></div>
                <router-link class="dropdown-item" to="/security/permisos">Registro de Permisos</router-link>
                <router-link class="dropdown-item" to="/security/roles">Registro de Roles</router-link>
                <div class="dropdown-divider"></div>
                <router-link class="dropdown-item" to="/security/permisos-roles">Asignar Permisos al Rol</router-link>                
              </div>
            </li>

            <!-- Módulo de Ubicación -->
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                aria-expanded="false">Ubicación</a>
              <div class="dropdown-menu">
                <router-link class="dropdown-item" to="/parameter/departamentos">Registro de Departamentos</router-link>
                <router-link class="dropdown-item" to="/parameter/ciudades">Registro de Ciudades</router-link>               
              </div>
            </li>


            <!-- Módulo de Admistración -->
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                aria-expanded="false">Administración Conjunto</a>
              <div class="dropdown-menu">
                <router-link class="dropdown-item" to="/estate/costes-adminsitracion">Registro de Costes de Administración</router-link>
                <router-link class="dropdown-item" to="/estate/tipos-inmuebles">Registro de Tipos Inmuebles</router-link>               
                <div class="dropdown-divider"></div>
                <router-link class="dropdown-item" to="/estate/inmuebles">Registro de Inmuebles</router-link>
                <router-link class="dropdown-item" to="/estate/datos-conjuntos">Registro del Cojunto</router-link>
                <div class="dropdown-divider"></div>
                <router-link class="dropdown-item" to="/estate/bitacoras">Registro de la Bitácora</router-link>
              </div>
            </li>
          </ul>
          <form class="d-flex">
            <input class="form-control me-sm-2" type="text" placeholder="Search">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>
  </div>
  <router-view />
</template>


<style>
  body{
      margin-top: 1%;
  }
</style>